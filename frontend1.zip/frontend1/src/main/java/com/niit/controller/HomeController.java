package com.niit.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.services.ProductService;


@Controller
public class HomeController {
	@Autowired
	private ProductService productService;

public HomeController(){
	System.out.println("HelloController GETS INTANTIATED");
}
@RequestMapping(value="/")
public String home(HttpSession session){
	session.setAttribute("categories",productService.getAllCategories() );
	return "home";
}
@RequestMapping(value="/aboutus")
public String aboutus(){
	return "aboutus";
	} 
@RequestMapping(value="/contactus")
public String contactus(){
	return "contactUs";
	} 

@RequestMapping(value="/login")
public String loginPage(@RequestParam(required=false) String error,@RequestParam(required=false) String logout,Model model){
	if(error!=null)
		model.addAttribute("error","Invalid Username/Password");
	if(logout!=null)
		model.addAttribute("message","Loggedout Successfully");
	return "login";
}
}
